package home.bsoft;

import home.bsoft.InputAndOutput.InputReader;
import home.bsoft.InputAndOutput.OutputWriter;

import java.io.IOException;

public class MainProgram {

    public static void main(String[] args) {
        try {
            InputReader.readCommands();
        } catch (IOException e) {
            OutputWriter.displayException(e.getMessage());
        }
    }
}
